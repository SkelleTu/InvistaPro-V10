import { sql } from 'drizzle-orm';
import {
  index,
  text,
  sqliteTable,
  real,
  integer,
} from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for express sessions
export const sessions = sqliteTable(
  "sessions",
  {
    sid: text("sid").primaryKey(),
    sess: text("sess").notNull(),
    expire: text("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Users table with complete personal information
export const users = sqliteTable("users", {
  id: text("id").primaryKey().default(sql`(hex(randomblob(16)))`),
  // Authentication fields
  email: text("email").unique().notNull(),
  passwordHash: text("password_hash").notNull(),
  
  // Personal information
  nomeCompleto: text("nome_completo").notNull(),
  cpf: text("cpf").unique().notNull(),
  telefone: text("telefone").notNull(),
  
  // Address information
  endereco: text("endereco").notNull(),
  cidade: text("cidade").notNull(),
  estado: text("estado").notNull(),
  cep: text("cep").notNull(),
  
  // PIX information
  chavePix: text("chave_pix").notNull(),
  tipoChavePix: text("tipo_chave_pix").notNull(), // email, cpf, telefone, chave_aleatoria
  
  // Verification and status
  telefoneVerificado: integer("telefone_verificado", { mode: 'boolean' }).default(false),
  codigoVerificacao: text("codigo_verificacao"),
  codigoExpiresAt: text("codigo_expires_at"),
  
  // Password recovery
  passwordResetToken: text("password_reset_token"),
  passwordResetTokenExpiresAt: text("password_reset_token_expires_at"),
  contaAprovada: integer("conta_aprovada", { mode: 'boolean' }).default(true),
  aprovadaPor: text("aprovada_por"),
  aprovadaEm: text("aprovada_em"),
  
  // Document verification for withdrawals
  documentosVerificados: integer("documentos_verificados", { mode: 'boolean' }).default(false),
  documentosAprovadosEm: text("documentos_aprovados_em"),
  
  // Admin privileges
  isAdmin: integer("is_admin", { mode: 'boolean' }).default(false),
  
  // Security features for hybrid authentication
  senhaFallback: text("senha_fallback"), // Hashed fallback password for PCs without biometric
  usarSenhaFallback: integer("usar_senha_fallback", { mode: 'boolean' }).default(false),
  biometriaConfigurada: integer("biometria_configurada", { mode: 'boolean' }).default(false),
  
  // Financial data
  saldo: real("saldo").default(0.00).notNull(),
  depositoData: text("deposito_data"),
  rendimentoSaqueAutomatico: integer("rendimento_saque_automatico", { mode: 'boolean' }).default(false),
  
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

export const movimentos = sqliteTable("movimentos", {
  id: text("id").primaryKey().default(sql`(hex(randomblob(16)))`),
  userId: text("user_id").notNull().references(() => users.id),
  tipo: text("tipo").notNull(), // 'deposito', 'rendimento', 'saque'
  valor: real("valor").notNull(),
  descricao: text("descricao"),
  pixString: text("pix_string"), // For PIX deposits
  biometriaVerificada: integer("biometria_verificada", { mode: 'boolean' }).default(false), // Security verification tracking

  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
});

// Document uploads table for KYC verification
export const documentos = sqliteTable("documentos", {
  id: text("id").primaryKey().default(sql`(hex(randomblob(16)))`),
  userId: text("user_id").notNull().references(() => users.id),
  tipo: text("tipo").notNull(), // 'rg_cnh_frente', 'rg_cnh_verso', 'comprovante_residencia'
  arquivo: text("arquivo").notNull(), // File path or URL
  status: text("status").default('pendente'), // 'pendente', 'aprovado', 'rejeitado'
  motivoRejeicao: text("motivo_rejeicao"),
  aprovadoPor: text("aprovado_por"),
  aprovadoEm: text("aprovado_em"),
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// KYC Status table for tracking overall verification status
export const kycStatus = sqliteTable("kyc_status", {
  id: text("id").primaryKey().default(sql`(hex(randomblob(16)))`),
  userId: text("user_id").notNull().references(() => users.id),
  status: text("status").default('pending'), // 'pending', 'under_review', 'approved', 'rejected'
  // Document status flags
  rgCnhFrenteStatus: text("rg_cnh_frente_status").default('pending'),
  rgCnhVersoStatus: text("rg_cnh_verso_status").default('pending'), 
  comprovanteResidenciaStatus: text("comprovante_residencia_status").default('pending'),
  // Overall completion
  completedAt: text("completed_at"),
  approvedAt: text("approved_at"),
  rejectedAt: text("rejected_at"),
  rejectionReason: text("rejection_reason"),
  reviewedBy: text("reviewed_by"), // Admin email who reviewed
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// Registration schema for new users with enhanced validation
export const registerUserSchema = createInsertSchema(users).omit({
  id: true,
  passwordHash: true,
  telefoneVerificado: true,
  codigoVerificacao: true,
  codigoExpiresAt: true,
  contaAprovada: true,
  aprovadaPor: true,
  aprovadaEm: true,
  documentosVerificados: true,
  documentosAprovadosEm: true,
  isAdmin: true,
  saldo: true,
  depositoData: true,
  rendimentoSaqueAutomatico: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
  confirmPassword: z.string(),
  cpf: z.string().min(11, "CPF deve ter 11 dígitos").max(14, "CPF inválido"),
  email: z.string().email("Email inválido"),
  telefone: z.string().min(10, "Telefone deve ter pelo menos 10 dígitos").max(15, "Telefone inválido"),
  cep: z.string().min(8, "CEP deve ter 8 dígitos").max(9, "CEP inválido"),
}).refine(data => data.password === data.confirmPassword, {
  message: "Senhas não coincidem",
  path: ["confirmPassword"],
});

// Login schema
export const loginSchema = z.object({
  email: z.string().email("Email inválido"),
  password: z.string().min(1, "Senha é obrigatória"),
});

// Phone verification schema
export const phoneVerificationSchema = z.object({
  userId: z.string().min(1, "ID do usuário é obrigatório"),
  codigo: z.string().length(6, "Código deve ter 6 dígitos"),
});

export const insertMovimentoSchema = createInsertSchema(movimentos).omit({
  id: true,
  createdAt: true,
});

export const insertDocumentoSchema = createInsertSchema(documentos).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
}).partial();

// Schema for document upload
export const uploadDocumentSchema = z.object({
  tipo: z.enum(['rg_cnh_frente', 'rg_cnh_verso', 'comprovante_residencia'], {
    required_error: "Tipo de documento é obrigatório"
  }),
  arquivo: z.string().min(1, "Arquivo é obrigatório"),
});

// Schema for admin document review
export const reviewDocumentSchema = z.object({
  documentId: z.string().min(1, "ID do documento é obrigatório"),
  status: z.enum(['aprovado', 'rejeitado'], {
    required_error: "Status é obrigatório"
  }),
  motivoRejeicao: z.string().optional(),
});



// Schema for withdrawal request
export const withdrawalRequestSchema = z.object({
  valor: z.number().min(0.01, "Valor deve ser maior que zero"),
  tipo: z.enum(['rendimento', 'total'], {
    required_error: "Tipo de saque é obrigatório"
  }),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type RegisterUser = z.infer<typeof registerUserSchema>;
export type LoginUser = z.infer<typeof loginSchema>;
export type PhoneVerification = z.infer<typeof phoneVerificationSchema>;
export type UpdateUser = z.infer<typeof updateUserSchema>;
export type Movimento = typeof movimentos.$inferSelect;
export type InsertMovimento = z.infer<typeof insertMovimentoSchema>;
export type Documento = typeof documentos.$inferSelect;
export type InsertDocumento = z.infer<typeof insertDocumentoSchema>;
export type UploadDocument = z.infer<typeof uploadDocumentSchema>;
export type KycStatus = typeof kycStatus.$inferSelect;
export type InsertKycStatus = typeof kycStatus.$inferInsert;
export type ReviewDocument = z.infer<typeof reviewDocumentSchema>;

export type WithdrawalRequest = z.infer<typeof withdrawalRequestSchema>;

// TRADING SYSTEM TABLES

// Deriv API tokens for authorized users
export const derivTokens = sqliteTable("deriv_tokens", {
  id: text("id").primaryKey().default(sql`(hex(randomblob(16)))`),
  userId: text("user_id").notNull().references(() => users.id),
  token: text("token").notNull(), // Encrypted Deriv API token
  accountType: text("account_type").notNull(), // 'demo' or 'real'
  isActive: integer("is_active", { mode: 'boolean' }).default(true),
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// Trading configurations for operation modes
export const tradeConfigurations = sqliteTable("trade_configurations", {
  id: text("id").primaryKey().default(sql`(hex(randomblob(16)))`),
  userId: text("user_id").notNull().references(() => users.id),
  mode: text("mode").notNull(), // 'production_3-4_24h', 'production_2_24h', 'test_4_1min', etc.
  isActive: integer("is_active", { mode: 'boolean' }).default(false),
  operationsCount: integer("operations_count").notNull(),
  intervalType: text("interval_type").notNull(), // 'minutes', 'hours', 'days'  
  intervalValue: integer("interval_value").notNull(),
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// AI analysis logs from Hugging Face models
export const aiLogs = sqliteTable("ai_logs", {
  id: text("id").primaryKey().default(sql`(hex(randomblob(16)))`),
  userId: text("user_id").notNull().references(() => users.id),
  modelName: text("model_name").notNull(),
  analysis: text("analysis").notNull(), // AI's detailed analysis in JSON
  decision: text("decision").notNull(), // 'buy', 'sell', 'hold'
  confidence: real("confidence").notNull(), // 0.0 to 1.0
  marketData: text("market_data").notNull(), // Market data used for analysis in JSON
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
});

// Trading operations tracking
export const tradeOperations = sqliteTable("trade_operations", {
  id: text("id").primaryKey().default(sql`(hex(randomblob(16)))`),
  userId: text("user_id").notNull().references(() => users.id),
  derivContractId: text("deriv_contract_id"), // Deriv's contract ID
  symbol: text("symbol").notNull(), // Trading symbol (e.g. 'R_100')
  tradeType: text("trade_type").notNull(), // 'digitdiff'
  direction: text("direction").notNull(), // 'up', 'down'
  amount: real("amount").notNull(), // Stake amount
  duration: integer("duration").notNull(), // Duration in ticks
  status: text("status").default('pending'), // 'pending', 'active', 'won', 'lost'
  entryPrice: real("entry_price"),
  exitPrice: real("exit_price"),
  profit: real("profit"),
  aiConsensus: text("ai_consensus").notNull(), // AI models' consensus in JSON
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
  completedAt: text("completed_at"),
});

// Real-time market data cache
export const marketData = sqliteTable("market_data", {
  id: text("id").primaryKey().default(sql`(hex(randomblob(16)))`),
  symbol: text("symbol").notNull(),
  currentPrice: real("current_price").notNull(),
  priceHistory: text("price_history").notNull(), // JSON array of recent prices
  lastUpdate: text("last_update").default(sql`CURRENT_TIMESTAMP`),
});

// TRADING SYSTEM SCHEMAS

export const insertDerivTokenSchema = createInsertSchema(derivTokens).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTradeConfigSchema = createInsertSchema(tradeConfigurations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTradeOperationSchema = createInsertSchema(tradeOperations).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertAiLogSchema = createInsertSchema(aiLogs).omit({
  id: true,
  createdAt: true,
});

export const insertMarketDataSchema = createInsertSchema(marketData).omit({
  id: true,
  lastUpdate: true,
});

// Trading form validation schemas
export const derivTokenConfigSchema = z.object({
  token: z.string().min(1, "Token Deriv é obrigatório"),
  accountType: z.enum(['demo', 'real'], {
    required_error: "Tipo de conta é obrigatório"
  }),
});

export const tradeModeConfigSchema = z.object({
  mode: z.enum([
    'production_3-4_24h', 'production_2_24h',
    'test_4_1min', 'test_3_2min', 'test_4_1hour', 'test_3_2hour'
  ], {
    required_error: "Modo de operação é obrigatório"
  }),
});

export const manualTradeSchema = z.object({
  symbol: z.string().min(1, "Símbolo é obrigatório"),
  direction: z.enum(['up', 'down'], {
    required_error: "Direção é obrigatória"
  }),
  amount: z.number().min(0.35, "Valor mínimo é 0.35").max(50000, "Valor máximo é 50000"),
  duration: z.number().min(1, "Duração mínima é 1 tick").max(10, "Duração máxima é 10 ticks"),
});

// TRADING SYSTEM TYPES

export type DerivToken = typeof derivTokens.$inferSelect;
export type InsertDerivToken = z.infer<typeof insertDerivTokenSchema>;
export type TradeConfiguration = typeof tradeConfigurations.$inferSelect;
export type InsertTradeConfiguration = z.infer<typeof insertTradeConfigSchema>;
export type TradeOperation = typeof tradeOperations.$inferSelect;
export type InsertTradeOperation = z.infer<typeof insertTradeOperationSchema>;
export type AiLog = typeof aiLogs.$inferSelect;
export type InsertAiLog = z.infer<typeof insertAiLogSchema>;
export type MarketData = typeof marketData.$inferSelect;
export type InsertMarketData = z.infer<typeof insertMarketDataSchema>;

export type DerivTokenConfig = z.infer<typeof derivTokenConfigSchema>;
export type TradeModeConfig = z.infer<typeof tradeModeConfigSchema>;
export type ManualTrade = z.infer<typeof manualTradeSchema>;


