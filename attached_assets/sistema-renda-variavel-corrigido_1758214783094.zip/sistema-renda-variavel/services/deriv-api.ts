import WebSocket from 'ws';
import { EventEmitter } from 'events';
import { errorTracker } from './error-tracker';

export interface DerivTickData {
  symbol: string;
  quote: number;
  epoch: number;
}

export interface DerivBalance {
  balance: number;
  currency: string;
  loginid: string;
}

export interface DerivContractInfo {
  contract_id: number;
  shortcode: string;
  status: string;
  entry_tick: number;
  exit_tick?: number;
  profit?: number;
  buy_price: number;
}

export interface DigitDifferContract {
  contract_type: 'DIGITDIFF';
  symbol: string;
  duration: number;
  duration_unit: 't'; // ticks
  barrier: string; // digit to predict difference from
  amount: number;
  currency: string;
}

  private derivUrl: string = 'wss://ws.derivws.com/websockets/v3';
  private appId: string = process.env.DERIV_APP_ID || '1089'; // substitua pelo seu app_id real
export class DerivAPIService extends EventEmitter {
  private ws: WebSocket | null = null;
  private connectionId: number = 0;
  private isConnected: boolean = false;
  private apiToken: string | null = null;
  private accountType: 'demo' | 'real' = 'demo';
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 1000;
  private maxQueueSize = 100;
  private messageQueue: any[] = [];
  private activeSubscriptions = new Set<string>();
  private isShuttingDown = false;
  private connectionTimeout: NodeJS.Timeout | null = null;
  private heartbeatInterval: NodeJS.Timeout | null = null;
  private startHeartbeat(): void {
    if (this.ws) {
      this.heartbeatInterval = setInterval(() => {
        this.sendMessage({ ping: 1 });
      }, 30000); // a cada 30s
    }
  }
  private operationId: string | null = null;

  constructor() {
    super();
    
    // Configurar listeners para error recovery
    this.setMaxListeners(20); // Evitar memory leaks
    this.setupErrorRecovery();
  }

  private setupErrorRecovery(): void {
    // Capturar erros não tratados
    this.on('error', (error) => {
      const errorId = errorTracker.captureError(
        error,
        'ERROR',
        'WEBSOCKET',
        {
          requestPath: 'DERIV_API_SERVICE',
          requestMethod: 'EVENT_ERROR',
          requestBody: {
            operationId: this.operationId,
            isConnected: this.isConnected,
            reconnectAttempts: this.reconnectAttempts,
            wsReadyState: this.ws?.readyState
          }
        }
      );
      
      console.log(`🔥 DERIV API ERROR CAPTURED - ID: ${errorId}`);
      
      // Não propagar o erro para evitar crashes
      // O error handling será feito internamente
    });

    // Setup graceful shutdown
    process.on('SIGTERM', () => this.gracefulShutdown());
    process.on('SIGINT', () => this.gracefulShutdown());
  }

  async connect(apiToken: string, accountType: 'demo' | 'real' = 'demo', operationId?: string): Promise<boolean> {
    this.operationId = operationId || `CONNECT_${Date.now()}`;
    this.apiToken = apiToken;
    this.accountType = accountType;
    this.isShuttingDown = false;
    
    const appId = process.env.DERIV_APP_ID || '1089';
    const endpoint = accountType === 'demo' 
      ? `wss://ws.derivws.com/websockets/v3?app_id=${appId}`
      : `wss://ws.derivws.com/websockets/v3?app_id=${appId}`;

    console.log(`🔌 Iniciando conexão Deriv - Operation ID: ${this.operationId}`);

    return new Promise((resolve, reject) => {
      const connectionTimer = setTimeout(() => {
        const timeoutError = new Error('Connection timeout after 10 seconds');
        
        errorTracker.captureError(
          timeoutError,
          'ERROR',
          'WEBSOCKET',
          {
            requestPath: 'DERIV_CONNECTION_TIMEOUT',
            requestMethod: 'CONNECT',
            requestBody: {
              operationId: this.operationId,
              endpoint,
              accountType,
              timeout: '10s'
            }
          }
        );
        
        this.cleanup();
        reject(timeoutError);
      }, 10000);

      try {
        this.ws = new WebSocket(endpoint, {
      this.ws.on('open', () => {
        if (this.apiToken) {
          this.sendMessage({ authorize: this.apiToken });
        }
      });
          headers: {
            'Origin': 'https://app.deriv.com'
          }
        });

        this.ws.on('open', async () => {
          clearTimeout(connectionTimer);
          console.log(`🔗 Deriv WebSocket conectado - Operation ID: ${this.operationId}`);
          this.isConnected = true;
          this.reconnectAttempts = 0;
          
          try {
            // Authenticate
            const authResult = await this.authenticate();
            if (authResult) {
              this.emit('connected');
              this.processMessageQueue();
              this.startHeartbeat();
              resolve(true);
            } else {
              const authError = new Error('Authentication failed');
              
              errorTracker.captureError(
                authError,
                'ERROR',
                'AUTH',
                {
                  requestPath: 'DERIV_AUTHENTICATION',
                  requestMethod: 'AUTHENTICATE',
                  requestBody: {
                    operationId: this.operationId,
                    accountType
                  }
                }
              );
              
              this.cleanup();
              reject(authError);
            }
          } catch (authError) {
            clearTimeout(connectionTimer);
            
            errorTracker.captureError(
              authError as Error,
              'ERROR',
              'AUTH',
              {
                requestPath: 'DERIV_AUTHENTICATION_EXCEPTION',
                requestMethod: 'AUTHENTICATE',
                requestBody: {
                  operationId: this.operationId,
                  accountType
                }
              }
            );
            
            this.cleanup();
            reject(authError);
          }
        });

        this.ws.on('message', (data) => {
      const data = JSON.parse(message.toString());
      if (data.msg_type) {
        switch (data.msg_type) {
          case 'authorize': this.emit('authorized', data); break;
          case 'tick': this.emit('tick', data.tick); break;
          case 'balance': this.emit('balance', data.balance); break;
          case 'proposal': this.emit('proposal', data.proposal); break;
          case 'buy': this.emit('buy', data.buy); break;
          case 'error': this.emit('error', data.error); break;
        }
      }
          try {
            const message = JSON.parse(data.toString());
            this.handleMessage(message);
          } catch (error) {
            errorTracker.captureError(
              error as Error,
              'WARNING',
              'WEBSOCKET',
              {
                requestPath: 'DERIV_MESSAGE_PARSE',
                requestMethod: 'MESSAGE',
                requestBody: {
                  operationId: this.operationId,
                  rawData: data.toString().substring(0, 200)
                }
              }
            );
          }
        });

        this.ws.on('close', (code, reason) => {
          clearTimeout(connectionTimer);
          
          const closeInfo = {
            code,
            reason: reason?.toString(),
            operationId: this.operationId,
            wasConnected: this.isConnected
          };
          
          console.log(`⚠️ Deriv WebSocket desconectado - Code: ${code}, Reason: ${reason}, Operation ID: ${this.operationId}`);
          
          this.isConnected = false;
          this.stopHeartbeat();
          this.emit('disconnected', closeInfo);
          
          // Não tentar reconectar automaticamente para evitar loops infinitos
          // A reconexão será controlada externamente quando necessário
        });

        this.ws.on('error', (error) => {
          clearTimeout(connectionTimer);
          
          const errorId = errorTracker.captureError(
            error,
            'ERROR',
            'WEBSOCKET',
            {
              requestPath: 'DERIV_CONNECTION_ERROR',
              requestMethod: 'CONNECT',
              requestBody: {
                operationId: this.operationId,
                endpoint,
                accountType,
                wsReadyState: this.ws?.readyState
              }
            }
          );
          
          console.log(`❌ Erro na conexão Deriv - Error ID: ${errorId}, Operation ID: ${this.operationId}`);
          
          this.isConnected = false;
          this.cleanup();
          reject(error);
        });

      } catch (error) {
        clearTimeout(connectionTimer);
        
        errorTracker.captureError(
          error as Error,
          'ERROR',
          'WEBSOCKET',
          {
            requestPath: 'DERIV_CONNECTION_SETUP',
            requestMethod: 'CONNECT',
            requestBody: {
              operationId: this.operationId,
              endpoint,
              accountType
            }
          }
        );
        
        console.error(`❌ Erro ao configurar conexão Deriv - Operation ID: ${this.operationId}:`, error);
        reject(error);
      }
    });
  }

  private startHeartbeat(): void {
    this.heartbeatInterval = setInterval(() => {
      if (this.isConnected && this.ws?.readyState === WebSocket.OPEN) {
        this.sendMessage({ ping: 1 });
      }
    }, 30000); // Ping a cada 30 segundos
  }

  private stopHeartbeat(): void {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
  }

  private cleanup(): void {
    this.stopHeartbeat();
    this.isConnected = false;
    
    if (this.connectionTimeout) {
      clearTimeout(this.connectionTimeout);
      this.connectionTimeout = null;
    }
    
    if (this.ws) {
      this.ws.removeAllListeners();
      if (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING) {
        this.ws.close();
      }
      this.ws = null;
    }
  }

  private async gracefulShutdown(): Promise<void> {
    this.isShuttingDown = true;
    console.log(`🛑 Iniciando shutdown graceful do Deriv API - Operation ID: ${this.operationId}`);
    
    await this.disconnect();
    this.removeAllListeners();
    
    console.log(`✅ Shutdown graceful concluído - Operation ID: ${this.operationId}`);
  }

  private async authenticate(): Promise<boolean> {
    if (!this.apiToken) return false;

    return new Promise((resolve) => {
      const reqId = this.generateRequestId();
      
      const authMessage = {
        authorize: this.apiToken,
        req_id: reqId
      };

      // Store auth handler
      const authHandler = (message: any) => {
        if (message.req_id === reqId) {
          this.removeListener('message', authHandler);
          if (message.authorize) {
            console.log('✅ Deriv autenticação realizada com sucesso');
            console.log(`📊 Conta: ${message.authorize.loginid} (${message.authorize.currency})`);
            resolve(true);
          } else {
            console.error('❌ Falha na autenticação Deriv:', message.error);
            resolve(false);
          }
        }
      };

      this.on('message', authHandler);
      this.sendMessage(authMessage);
    });
  }

  async getBalance(): Promise<DerivBalance | null> {
    if (!this.isConnected) return null;

    return new Promise((resolve) => {
      const reqId = this.generateRequestId();
      
      const balanceHandler = (message: any) => {
        if (message.req_id === reqId) {
          this.removeListener('message', balanceHandler);
          if (message.balance) {
            resolve({
              balance: message.balance.balance,
              currency: message.balance.currency,
              loginid: message.balance.loginid
            });
          } else {
            resolve(null);
          }
        }
      };

      this.on('message', balanceHandler);
      this.sendMessage({ balance: 1, req_id: reqId });
    });
  }

  async subscribeToTicks(symbol: string): Promise<void> {
    if (!this.isConnected) {
      this.sendMessage({ type: 'subscribe_ticks', symbol });
      return;
    }

    const subscriptionKey = `ticks_${symbol}`;
    if (this.activeSubscriptions.has(subscriptionKey)) {
      return; // Already subscribed
    }

    const reqId = this.generateRequestId();
    
    const subscribeMessage = {
      ticks: symbol,
      subscribe: 1,
      req_id: reqId
    };

    this.sendMessage(subscribeMessage);
    this.activeSubscriptions.add(subscriptionKey);
    console.log(`📈 Inscrito nos ticks de ${symbol}`);
  }

  async buyDigitDifferContract(params: DigitDifferContract): Promise<DerivContractInfo | null> {
    if (!this.isConnected) return null;

    return new Promise((resolve) => {
      const reqId = this.generateRequestId();
      
      const buyHandler = (message: any) => {
        if (message.req_id === reqId) {
          this.removeListener('message', buyHandler);
          if (message.buy) {
            const contract: DerivContractInfo = {
              contract_id: message.buy.contract_id,
              shortcode: message.buy.shortcode,
              status: 'active',
              entry_tick: 0, // Will be updated
              buy_price: message.buy.buy_price,
            };
            
            console.log(`✅ Contrato comprado: ${contract.contract_id}`);
            resolve(contract);
          } else {
            console.error('❌ Erro ao comprar contrato:', message.error);
            resolve(null);
          }
        }
      };

      this.on('message', buyHandler);

      // Create digit differ buy request
      const buyMessage = {
        buy: 1,
        price: params.amount,
        parameters: {
          contract_type: 'DIGITDIFF',
          symbol: params.symbol,
          duration: params.duration,
          duration_unit: 't',
          barrier: params.barrier,
        },
        req_id: reqId
      };

      this.sendMessage(buyMessage);
    });
  }

  async getContractInfo(contractId: number): Promise<DerivContractInfo | null> {
    if (!this.isConnected) return null;

    return new Promise((resolve) => {
      const reqId = this.generateRequestId();
      
      const contractHandler = (message: any) => {
        if (message.req_id === reqId) {
          this.removeListener('message', contractHandler);
          if (message.proposal_open_contract) {
            const contract = message.proposal_open_contract;
            resolve({
              contract_id: contract.contract_id,
              shortcode: contract.shortcode,
              status: contract.status,
              entry_tick: contract.entry_tick,
              exit_tick: contract.exit_tick,
              profit: contract.profit,
              buy_price: contract.buy_price,
            });
          } else {
            resolve(null);
          }
        }
      };

      this.on('message', contractHandler);
      this.sendMessage({ proposal_open_contract: 1, contract_id: contractId, req_id: reqId });
    });
  }

  private handleMessage(message: any): void {
    this.emit('message', message);

    // Handle specific message types
    if (message.tick) {
      const tickData: DerivTickData = {
        symbol: message.tick.symbol,
        quote: message.tick.quote,
        epoch: message.tick.epoch
      };
      this.emit('tick', tickData);
    }

    if (message.proposal_open_contract) {
      this.emit('contract_update', message.proposal_open_contract);
    }

    if (message.balance) {
      this.emit('balance_update', message.balance);
    }
  }

  private sendMessage(message: any): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    } else {
      // Queue message with size limit to prevent memory issues
      if (this.messageQueue.length < this.maxQueueSize) {
        this.messageQueue.push(message);
      } else {
        console.warn('⚠️ Message queue full, dropping oldest message');
        this.messageQueue.shift();
        this.messageQueue.push(message);
      }
    }
  }

  private processMessageQueue(): void {
    while (this.messageQueue.length > 0 && this.isConnected) {
      const message = this.messageQueue.shift();
      
      if (message.type === 'subscribe_ticks') {
        this.subscribeToTicks(message.symbol);
      } else {
        this.sendMessage(message);
      }
    }
  }

  private attemptReconnection(): void {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error('❌ Máximo de tentativas de reconexão atingido');
      return;
    }

    this.reconnectAttempts++;
    console.log(`🔄 Tentativa de reconexão ${this.reconnectAttempts}/${this.maxReconnectAttempts}`);

    setTimeout(() => {
      if (this.apiToken) {
        this.connect(this.apiToken, this.accountType);
      }
    }, this.reconnectDelay * this.reconnectAttempts);
  }

  private generateRequestId(): number {
    return ++this.connectionId;
  }

  async disconnect(): Promise<void> {
    this.isConnected = false;
    this.activeSubscriptions.clear();
    
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    
    console.log('🔌 Deriv desconectado');
  }

  isApiConnected(): boolean {
    return this.isConnected;
  }

  getActiveSubscriptions(): string[] {
    return Array.from(this.activeSubscriptions);
  }
}

// Singleton instance
export const derivAPI = new DerivAPIService();