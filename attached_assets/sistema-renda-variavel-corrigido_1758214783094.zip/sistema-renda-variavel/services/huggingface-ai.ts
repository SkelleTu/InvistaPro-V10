import axios from 'axios';
import { DerivTickData } from './deriv-api';

export interface AIModel {
  name: string;
  id: string;
  description: string;
  confidence: number;
}

export interface MarketAnalysis {
  modelName: string;
  prediction: 'up' | 'down' | 'neutral';
  confidence: number;
  reasoning: string;
  marketData: DerivTickData[];
  timestamp: Date;
}

export interface AIConsensus {
  finalDecision: 'up' | 'down' | 'neutral';
  consensusStrength: number; // 0-100%
  participatingModels: number;
  analyses: MarketAnalysis[];
  reasoning: string;
}

export interface DigitDifferAnalysis {
  lastDigit: number;
  predictedDigit: number;
  digitDifference: number;
  probability: number;
  reasoning: string;
}

export class HuggingFaceAIService {
  private apiKey: string;
  private isConfigured: boolean = true;
  private baseURL = 'https://api-inference.huggingface.co';
  private activeModels: AIModel[] = [
    {
      name: 'FinBERT Financial Sentiment',
      id: 'ProsusAI/finbert',
      description: 'Specialized in financial text analysis and sentiment',
      confidence: 0.85
    },
    {
      name: 'Financial Transformer',
      id: 'EleutherAI/gpt-j-6b',
      description: 'Large language model for financial predictions',
      confidence: 0.80
    },
    {
      name: 'Time Series Forecasting',
      id: 'facebook/prophet',
      description: 'Specialized in time series forecasting',
      confidence: 0.75
    },
    {
      name: 'Market Sentiment Analyzer',
      id: 'cardiffnlp/twitter-roberta-base-sentiment-latest',
      description: 'Advanced sentiment analysis for market data',
      confidence: 0.70
    },
    {
      name: 'Numerical Pattern Recognition',
      id: 'microsoft/DialoGPT-large',
      description: 'Pattern recognition in numerical sequences',
      confidence: 0.78
    }
  ];

  constructor() {
    const apiKey = process.env.HUGGINGFACE_API_KEY;
    if (!apiKey) {
      // Log menos verboso - apenas uma vez no startup
      this.apiKey = 'development-mode';
      this.isConfigured = false;
      return;
    }
    this.apiKey = apiKey;
  }

  async analyzeMarketData(tickData: DerivTickData[], symbol: string): Promise<AIConsensus> {
    // Handle case when API key is not configured
    if (!this.isConfigured) {
      return this.generateMockConsensus(tickData, symbol);
    }
    
    console.log(`🤖 Iniciando análise cooperativa com ${this.activeModels.length} modelos de IA`);
    console.log(`📊 Analisando ${tickData.length} ticks de ${symbol}`);

    const analyses: MarketAnalysis[] = [];
    
    // Execute analysis with all models in parallel
    const analysisPromises = this.activeModels.map(model => 
      this.analyzeWithModel(model, tickData, symbol)
    );

    try {
      const results = await Promise.allSettled(analysisPromises);
      
      results.forEach((result, index) => {
        if (result.status === 'fulfilled' && result.value) {
          analyses.push(result.value);
          console.log(`✅ ${this.activeModels[index].name}: ${result.value.prediction} (confiança: ${result.value.confidence}%)`);
        } else {
          console.warn(`⚠️ ${this.activeModels[index].name} falhou:`, result.status === 'rejected' ? result.reason : 'No result');
        }
      });

      // Generate consensus from all analyses
      const consensus = this.generateConsensus(analyses);
      
      console.log(`🎯 Consenso final: ${consensus.finalDecision} (força: ${consensus.consensusStrength}%)`);
      console.log(`🧠 Participaram: ${consensus.participatingModels} modelos`);
      
      return consensus;

    } catch (error) {
      console.error('❌ Erro na análise cooperativa:', error);
      
      // Generate fallback consensus if all AI models fail
      if (analyses.length === 0) {
        console.warn('⚠️ Todos os modelos AI falharam, gerando consenso de fallback');
        return this.generateMockConsensus(tickData, symbol);
      }
      
      throw new Error(`Failed to complete AI analysis: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private async analyzeWithModel(model: AIModel, tickData: DerivTickData[], symbol: string): Promise<MarketAnalysis | null> {
    try {
      // Prepare market data for analysis
      const marketSummary = this.prepareMarketSummary(tickData, symbol);
      
      // Create specialized prompt for each model type
      const prompt = this.createModelSpecificPrompt(model, marketSummary, tickData);
      
      // Send request to Hugging Face
      const response = await axios.post(
        `${this.baseURL}/models/${model.id}`,
        {
          inputs: prompt,
          parameters: {
            max_new_tokens: 200,
            temperature: 0.7,
            return_full_text: false
          }
        },
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
          },
          timeout: 30000
        }
      );

      // Process model response
      const analysis = this.processModelResponse(model, response.data, tickData);
      
      return analysis;

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.warn(`⚠️ Modelo ${model.name} não conseguiu processar:`, errorMessage);
      return null;
    }
  }

  private prepareMarketSummary(tickData: DerivTickData[], symbol: string): string {
    if (tickData.length === 0) return `No data available for ${symbol}`;

    const latest = tickData[tickData.length - 1];
    const oldest = tickData[0];
    const priceChange = ((latest.quote - oldest.quote) / oldest.quote) * 100;
    
    // Calculate price statistics
    const prices = tickData.map(t => t.quote);
    const avgPrice = prices.reduce((a, b) => a + b, 0) / prices.length;
    const maxPrice = Math.max(...prices);
    const minPrice = Math.min(...prices);
    const volatility = this.calculateVolatility(prices);

    // Analyze digit patterns for digit differs
    const lastDigits = prices.map(p => Math.floor((p * 10000) % 10));
    const digitFrequency = this.analyzeDigitFrequency(lastDigits);

    return `
Market Analysis for ${symbol}:
- Current Price: ${latest.quote}
- Price Change: ${priceChange.toFixed(4)}%
- Average Price: ${avgPrice.toFixed(5)}
- Price Range: ${minPrice.toFixed(5)} - ${maxPrice.toFixed(5)}
- Volatility: ${volatility.toFixed(4)}
- Data Points: ${tickData.length}
- Last Digit Distribution: ${JSON.stringify(digitFrequency)}
- Recent Last Digits: ${lastDigits.slice(-10).join(', ')}
- Trend: ${priceChange > 0 ? 'Bullish' : 'Bearish'}
`;
  }

  private createModelSpecificPrompt(model: AIModel, marketSummary: string, tickData: DerivTickData[]): string {
    const baseContext = `
You are analyzing market data for Deriv digit differs trading. Your task is to predict whether the last digit of the next price will be higher or lower than the current last digit.

${marketSummary}

Based on this data, provide your analysis in the following JSON format:
{
  "prediction": "up|down|neutral",
  "confidence": 0-100,
  "reasoning": "detailed explanation of your analysis",
  "digitAnalysis": {
    "currentLastDigit": number,
    "predictedDirection": "up|down",
    "probability": 0-100
  }
}
`;

    // Customize prompt based on model specialization
    switch (model.name) {
      case 'FinBERT Financial Sentiment':
        return `${baseContext}

Focus on financial sentiment and market psychology patterns in the price movements. Consider market sentiment indicators and behavioral finance principles.`;

      case 'Financial Transformer':
        return `${baseContext}

Use advanced financial modeling techniques to analyze price patterns, support/resistance levels, and market microstructure.`;

      case 'Time Series Forecasting':
        return `${baseContext}

Apply time series analysis techniques including trend analysis, seasonality, and forecasting models to predict next price movements.`;

      case 'Market Sentiment Analyzer':
        return `${baseContext}

Analyze the underlying market sentiment from price action patterns and volume-based indicators.`;

      case 'Numerical Pattern Recognition':
        return `${baseContext}

Focus on numerical patterns and sequences in the last digits. Look for recurring patterns, cycles, and mathematical relationships.`;

      default:
        return baseContext;
    }
  }

  private processModelResponse(model: AIModel, response: any, tickData: DerivTickData[]): MarketAnalysis {
    try {
      // Handle different response formats from different models
      let responseText = '';
      
      if (Array.isArray(response)) {
        responseText = response[0]?.generated_text || response[0]?.text || JSON.stringify(response[0]);
      } else if (typeof response === 'string') {
        responseText = response;
      } else {
        responseText = response.generated_text || response.text || JSON.stringify(response);
      }

      // Try to extract JSON from response
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      let analysisData;
      
      if (jsonMatch) {
        try {
          analysisData = JSON.parse(jsonMatch[0]);
        } catch {
          // If JSON parsing fails, create analysis from text
          analysisData = this.parseTextResponse(responseText);
        }
      } else {
        analysisData = this.parseTextResponse(responseText);
      }

      return {
        modelName: model.name,
        prediction: this.normalizePrediction(analysisData.prediction || 'neutral'),
        confidence: Math.min(100, Math.max(0, analysisData.confidence || 50)),
        reasoning: analysisData.reasoning || responseText.substring(0, 200),
        marketData: tickData,
        timestamp: new Date()
      };

    } catch (error) {
      console.warn(`⚠️ Erro ao processar resposta do modelo ${model.name}:`, error);
      
      const errorMessage = error instanceof Error ? error.message : String(error);
      // Return default analysis
      return {
        modelName: model.name,
        prediction: 'neutral',
        confidence: 30,
        reasoning: `Analysis failed for ${model.name}: ${errorMessage}`,
        marketData: tickData,
        timestamp: new Date()
      };
    }
  }

  private parseTextResponse(text: string): any {
    // Simple text parsing for non-JSON responses
    const lowerText = text.toLowerCase();
    
    let prediction = 'neutral';
    let confidence = 50;
    
    if (lowerText.includes('up') || lowerText.includes('bullish') || lowerText.includes('higher')) {
      prediction = 'up';
      confidence = 60;
    } else if (lowerText.includes('down') || lowerText.includes('bearish') || lowerText.includes('lower')) {
      prediction = 'down';
      confidence = 60;
    }

    // Try to extract confidence numbers
    const confidenceMatch = text.match(/(\d+)%|\b(\d+)\s*confidence/i);
    if (confidenceMatch) {
      confidence = parseInt(confidenceMatch[1] || confidenceMatch[2], 10);
    }

    return {
      prediction,
      confidence,
      reasoning: text.substring(0, 200)
    };
  }

  private normalizePrediction(prediction: string): 'up' | 'down' | 'neutral' {
    const normalized = prediction.toLowerCase().trim();
    
    if (normalized.includes('up') || normalized.includes('bull') || normalized.includes('high')) {
      return 'up';
    } else if (normalized.includes('down') || normalized.includes('bear') || normalized.includes('low')) {
      return 'down';
    } else {
      return 'neutral';
    }
  }

  private generateConsensus(analyses: MarketAnalysis[]): AIConsensus {
    if (analyses.length === 0) {
      return {
        finalDecision: 'neutral',
        consensusStrength: 0,
        participatingModels: 0,
        analyses: [],
        reasoning: 'No AI models provided analysis'
      };
    }

    // Weight votes by confidence
    let upVotes = 0;
    let downVotes = 0;
    let neutralVotes = 0;
    let totalWeight = 0;

    analyses.forEach(analysis => {
      const weight = analysis.confidence / 100;
      totalWeight += weight;
      
      switch (analysis.prediction) {
        case 'up':
          upVotes += weight;
          break;
        case 'down':
          downVotes += weight;
          break;
        case 'neutral':
          neutralVotes += weight;
          break;
      }
    });

    // Determine final decision
    let finalDecision: 'up' | 'down' | 'neutral';
    let winningVotes: number;
    
    if (upVotes > downVotes && upVotes > neutralVotes) {
      finalDecision = 'up';
      winningVotes = upVotes;
    } else if (downVotes > upVotes && downVotes > neutralVotes) {
      finalDecision = 'down';
      winningVotes = downVotes;
    } else {
      finalDecision = 'neutral';
      winningVotes = neutralVotes;
    }

    // Calculate consensus strength
    const consensusStrength = totalWeight > 0 ? Math.round((winningVotes / totalWeight) * 100) : 0;

    // Generate reasoning
    const reasoning = this.generateConsensusReasoning(analyses, finalDecision, consensusStrength);

    return {
      finalDecision,
      consensusStrength,
      participatingModels: analyses.length,
      analyses,
      reasoning
    };
  }

  private generateConsensusReasoning(analyses: MarketAnalysis[], decision: string, strength: number): string {
    const modelNames = analyses.map(a => a.modelName).join(', ');
    const avgConfidence = analyses.reduce((sum, a) => sum + a.confidence, 0) / analyses.length;
    
    const upCount = analyses.filter(a => a.prediction === 'up').length;
    const downCount = analyses.filter(a => a.prediction === 'down').length;
    const neutralCount = analyses.filter(a => a.prediction === 'neutral').length;

    return `Análise cooperativa de ${analyses.length} modelos de IA (${modelNames}). 
Votação: ${upCount} UP, ${downCount} DOWN, ${neutralCount} NEUTRAL. 
Decisão: ${decision.toUpperCase()} com força de consenso ${strength}% e confiança média ${avgConfidence.toFixed(1)}%.
Os modelos identificaram padrões convergentes nos dados de mercado que indicam ${decision === 'up' ? 'tendência de alta' : decision === 'down' ? 'tendência de baixa' : 'condições neutras'}.`;
  }

  private calculateVolatility(prices: number[]): number {
    if (prices.length < 2) return 0;
    
    const returns = [];
    for (let i = 1; i < prices.length; i++) {
      returns.push((prices[i] - prices[i-1]) / prices[i-1]);
    }
    
    const avgReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
    const variance = returns.reduce((sum, ret) => sum + Math.pow(ret - avgReturn, 2), 0) / returns.length;
    
    return Math.sqrt(variance);
  }

  private analyzeDigitFrequency(digits: number[]): Record<number, number> {
    const frequency: Record<number, number> = {};
    
    digits.forEach(digit => {
      frequency[digit] = (frequency[digit] || 0) + 1;
    });
    
    return frequency;
  }

  async analyzeDigitDiffers(tickData: DerivTickData[], targetDigit: number): Promise<DigitDifferAnalysis> {
    const prices = tickData.map(t => t.quote);
    const lastDigits = prices.map(p => Math.floor((p * 10000) % 10));
    
    if (lastDigits.length === 0) {
      throw new Error('No price data available for digit analysis');
    }

    const currentLastDigit = lastDigits[lastDigits.length - 1];
    const digitFrequency = this.analyzeDigitFrequency(lastDigits);
    
    // Analyze patterns and predict next digit
    const predictedDigit = this.predictNextDigit(lastDigits);
    const digitDifference = Math.abs(predictedDigit - targetDigit);
    
    // Calculate probability based on historical patterns
    const probability = this.calculateDigitProbability(lastDigits, targetDigit);

    return {
      lastDigit: currentLastDigit,
      predictedDigit,
      digitDifference,
      probability,
      reasoning: `Análise baseada em ${lastDigits.length} dados históricos. 
      Dígito atual: ${currentLastDigit}, Previsto: ${predictedDigit}, 
      Diferença alvo: ${digitDifference}. Probabilidade: ${probability.toFixed(1)}%`
    };
  }

  private predictNextDigit(lastDigits: number[]): number {
    if (lastDigits.length < 3) return Math.floor(Math.random() * 10);
    
    // Simple pattern analysis - look for recent trends
    const recent = lastDigits.slice(-5);
    const frequency = this.analyzeDigitFrequency(recent);
    
    // Find most common digit in recent data
    const mostCommon = Object.entries(frequency)
      .sort(([,a], [,b]) => b - a)
      .map(([digit]) => parseInt(digit))[0];
      
    return mostCommon || Math.floor(Math.random() * 10);
  }

  private calculateDigitProbability(lastDigits: number[], targetDigit: number): number {
    const frequency = this.analyzeDigitFrequency(lastDigits);
    const total = lastDigits.length;
    const targetFreq = frequency[targetDigit] || 0;
    
    // Base probability with some weighting for recent occurrences
    const baseProbability = (targetFreq / total) * 100;
    
    // Check recent trend
    const recentDigits = lastDigits.slice(-10);
    const recentTargetCount = recentDigits.filter(d => d === targetDigit).length;
    const recentProbability = (recentTargetCount / recentDigits.length) * 100;
    
    // Weighted average favoring recent data
    return (baseProbability * 0.3) + (recentProbability * 0.7);
  }

  getActiveModels(): AIModel[] {
    return [...this.activeModels];
  }

  async testModelConnection(modelId: string): Promise<boolean> {
    try {
      const response = await axios.post(
        `${this.baseURL}/models/${modelId}`,
        { inputs: "Test connection" },
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
          },
          timeout: 10000
        }
      );
      
      return response.status === 200;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.warn(`Model ${modelId} connection failed:`, errorMessage);
      return false;
    }
  }

  // Generate mock consensus when API is not configured
  private generateMockConsensus(tickData: DerivTickData[], symbol: string): AIConsensus {
    const lastPrice = tickData[tickData.length - 1]?.quote || 0;
    const firstPrice = tickData[0]?.quote || 0;
    const trend = lastPrice > firstPrice ? 'up' : 'down';
    
    return {
      finalDecision: trend,
      consensusStrength: 65, // Moderate confidence for mock data
      participatingModels: 1,
      analyses: [{
        modelName: 'Mock Analysis (Development Mode)',
        prediction: trend,
        confidence: 65,
        reasoning: 'Análise simulada baseada na tendência de preços - HuggingFace API não configurado',
        marketData: tickData,
        timestamp: new Date()
      }],
      reasoning: 'Análise simulada para desenvolvimento - configure HUGGINGFACE_API_KEY para análise real'
    };
  }
}

// Singleton instance
export const huggingFaceAI = new HuggingFaceAIService();